# DIOappToDOList
App de tarefas feito com o desenvolvedor Ezequiel Messore na plataforma Digital Innovation One - Santander Bootcamp
